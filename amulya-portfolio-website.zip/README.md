# Alex Dev — Portfolio

Personal portfolio website built with pure HTML, CSS, and vanilla JavaScript. No frameworks, no dependencies, no build step.

## 🚀 Deploy to GitHub Pages

1. Create a new repository named `<your-username>.github.io`
2. Push all files to the `main` branch
3. Go to **Settings → Pages → Source → Deploy from branch → main**
4. Your site will be live at `https://<your-username>.github.io`

## 📁 File Structure

```
├── index.html       # Main portfolio page (all-in-one)
└── README.md        # This file
```

## ✏️ Customization Checklist

Open `index.html` and find & replace the following:

| Placeholder | Replace with |
|---|---|
| `Alex Dev` / `Alex.dev` | Your name |
| `hello@alexdev.io` | Your email |
| `Software Engineer · 4 Years Experience` | Your title & experience |
| `Based in San Francisco` | Your location |
| `TechCorp Inc.` / `StartupXYZ` / `Agency Co.` | Your employers |
| `Project Alpha` / `Dataflow API` / `DevBoard` | Your projects |
| `@alexchen` (GitHub/LinkedIn/Twitter) | Your handles |
| `#` in `<a href="#">` links | Your actual URLs |

## 🎨 Color Palette

| Variable | Value | Usage |
|---|---|---|
| `--bg` | `#0d1117` | Page background |
| `--surface` | `#121820` | Section backgrounds |
| `--accent` | `#c9a84c` | Gold highlights |
| `--accent2` | `#7eb8c9` | Steel blue tags |
| `--text` | `#e8e2d9` | Primary text |
| `--muted` | `#6b7a8d` | Secondary text |

To change the color scheme, edit the `:root` variables at the top of the `<style>` block.
